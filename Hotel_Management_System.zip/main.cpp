#include <iostream>
#include<cstdlib>
using namespace std;
class Hotel
{
	private:
		string name;
		int room_no;
		string address;
		string phone;
		string email;
		int num_days;
		int num_guests;
		int total_booking;
		bool has_paid;
		float total_amount;
		float total_revenue;
		bool is_under_maintenance;
	public:
		void book_room();
		void display_bill();
		void check_in();
		void check_out();
		void mark_under_maintenance();
		void mark_available();
		void manage_customer();
		void generate_report();
		string customer_feedback;
		string customer_preferences;
};
void Hotel::book_room()//Function to book a room
{
	system("cls");
	cout<<"\n\n\tHotel Management System-Report Generation\n\n";
	cout<<"please enter your details\n";
	cout<<"\nName:";
	cin>>name;
	cout<<"\nAdress:";
	cin>>address;
	cout<<"\nPhone:";
	cin>>phone;
	cout<<"\nEmail:";
	cin>>email;
	cout<<"\nNumber of Days:";
	cin>>num_days;
	cout<<"\nNumber of Guests:";
	cin>>num_guests;
	has_paid=false;
	is_under_maintenance=true;
	total_amount=num_days*num_guests*50.0;
	cout<<"\n\nCongratulations! Your n-booking is complete!\n";
	system("pause");
}
void Hotel::display_bill()//Function to display billing information
{
	system("cls");
	cout<<"\n\n\tHotel Management System-Customer Management\n\n";
	cout<<"Enter customer feedback:";
	cin>>customer_feedback;
	cout<<"Enter customer preferences:";
	cin>>customer_preferences;
	cout<<"\nCustomer feedback:"<<customer_feedback<<endl;
	cout<<"Customer preferences:"<<customer_preferences<<endl;
	cout<<"Bill for Room#"<<room_no<<"\n\n";
	cout<<"Name:"<<name<<endl;
	cout<<"Address:"<<address<<endl;
	cout<<"Phone:"<<phone<<endl;
	cout<<"Email:"<<email<<endl;
	cout<<"Number of Days:"<<num_days<<endl;
	cout<<"Number of Guests:"<<num_guests<<endl;
	cout<<"Total Amount:"<<total_amount<<endl;
	has_paid=true;
	is_under_maintenance=true;
	cout<<"Room is now under maintenance.\n";
	system("pause");
	cout<<"nCustomer information updated.\n";
	system("pause");
	cout<<"\n\nPayment has been received.Thank you for choosing our hotel!"<<endl;
	system("pause");
}
void Hotel::check_out()//Function to check out of a room
{
	if(has_paid){cout<<"\nYou hsve already made your payment.\n\n";
	}
	{
		display_bill();
		cout<<"Room is now available for booking.\n";
		system("system");
		cout<<"\n\nPlease complete the payment in order to check in.\n";
		system("pause");
		cout<<"\n\nPlease complete the payment in order to check out.\n";
		system("pause");
		}
	}	
	int main() {
		Hotel h;
		int choice;
		do{
			system("cls");
			cout<<"\n\n\tHotel Management System\n\n";
			cout<<"\t1.Book a Room\n\t2.Check-out of Room\n\3.Mark Room Under Maintenance\n\4.Mark Room Available\n\5.Manage Customer\n\6.Exit\n\nPlease enter your choice:";
			cin>>choice;
			switch(choice)
			{
				case 1:h.book_room();break;
				case 2:h.check_out();break;
				default:cout<<"\nInvalid Choice.Please try again.\n\n";system("pause");break;
			}
		}while(choice!=3);
	return 0;
}
